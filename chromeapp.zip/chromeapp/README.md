# Open Project
Opend project updater
Currently its only working for Fingent's open project website
If you are need for your company pls mail to justnshalom@gmail.com
https://openproject.fingent.net/